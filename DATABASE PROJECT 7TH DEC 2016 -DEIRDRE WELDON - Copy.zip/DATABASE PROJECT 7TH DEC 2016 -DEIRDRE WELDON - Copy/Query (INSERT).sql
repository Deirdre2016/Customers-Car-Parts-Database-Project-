/*INSERTING INTO BRANDS TABLE, VALUES FOR BRAND_ID, BRAND_NAME, BRAND_DETAILS. */

INSERT INTO Brands (Brand_id, Brand_name, Brand_details)
VALUES (1,'Vauxhall','Powerful Engine);
Collapse Edit Queried time: 4:6:56
/*INSERTING INTO BRANDS TABLE, VALUES FOR BRAND_ID, BRAND_NAME, BRAND_DETAILS. */

INSERT INTO Brands (Brand_id, Brand_name, Brand_details)
VALUES (1,'Vauxhall','Powerful Engine');
Collapse Edit Queried time: 4:8:23
/*INSERTING INTO BRANDS TABLE, VALUES FOR BRAND_ID, BRAND_NAME, BRAND_DETAILS. */

INSERT INTO Brands (Brand_id, Brand_name, Brand_details)
VALUES (1,'Vauxhall','Powerful Engine');
Collapse Edit Queried time: 4:10:54
/*INSERTING INTO BRANDS TABLE, VALUES FOR BRAND_ID, BRAND_NAME, BRAND_DETAILS. */

INSERT INTO Brands (Brand_name)
VALUES ('BMW');
Collapse Edit Queried time: 4:22:56
